<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&family=Open+Sans:wght@400;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="styles.css">

<?php
include 'config/db.php';
include 'views/header.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Seleciona as postagens e usuários relacionados
$stmt = $pdo->query('SELECT posts.id, users.username, users.profile_pic, posts.content, posts.image_path, posts.youtube_link, posts.created_at, posts.user_id FROM posts JOIN users ON posts.user_id = users.id ORDER BY posts.created_at DESC');

$emojis = ['👍', '❤️', '😂', '😮', '😢', '😡']; // Lista de emojis

// Exibe todas as postagens
while ($row = $stmt->fetch()) {
    echo "<div class='card mb-3'>";
    echo "<div class='card-body'>";
    echo "<div class='media'>";
    
    // Exibir a foto de perfil do usuário
    if ($row['profile_pic']) {
        echo "<img src='" . htmlspecialchars($row['profile_pic']) . "' class='mr-3 rounded-circle' alt='Profile Picture' style='width: 50px; height: 50px;'>";
    } else {
        echo "<img src='default-profile.png' class='mr-3 rounded-circle' alt='Default Profile Picture' style='width: 50px; height: 50px;'>";
    }

    echo "<div class='media-body'>";
    echo "<h5 class='mt-0'>" . htmlspecialchars($row['username']) . "</h5>";
    echo "<p>" . htmlspecialchars($row['content']) . "</p>";

    // Exibir imagem e vídeo do YouTube (se existir)
    if ($row['image_path']) {
        echo "<img src='" . htmlspecialchars($row['image_path']) . "' class='img-fluid rounded mb-3' alt='Post Image'>";
    }

    if ($row['youtube_link']) {
        preg_match('/(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:[^\/\n\s]+\/\S\/|(?:v|e(?:mbed)?)\/|\S*?[?&]v=)|youtu\.be\/)([a-zA-Z0-9_-]{11})/', $row['youtube_link'], $matches);
        if (isset($matches[1])) {
            $youtube_id = $matches[1];
            echo "<div class='embed-responsive embed-responsive-16by9 mb-3'>";
            echo "<iframe class='embed-responsive-item' src='https://www.youtube.com/embed/" . htmlspecialchars($youtube_id) . "' allowfullscreen></iframe>";
            echo "</div>";
        }
    }

    echo "<p class='text-muted'><small>" . htmlspecialchars($row['created_at']) . "</small></p>";

    // Botões de reação com emojis
    echo "<div class='emoji-reactions'>";
    foreach ($emojis as $emoji) {
        echo "<button class='emoji-btn' data-post-id='" . $row['id'] . "' data-emoji='" . htmlspecialchars($emoji) . "'>$emoji</button>";
    }
    echo "</div>";

    // Mostrar as reações existentes
    $reactions_stmt = $pdo->prepare('SELECT emoji, COUNT(*) as count FROM reactions WHERE post_id = :post_id GROUP BY emoji');
    $reactions_stmt->execute(['post_id' => $row['id']]);
    echo "<div class='reactions-summary'>";
    while ($reaction = $reactions_stmt->fetch()) {
        echo "<span data-emoji='" . htmlspecialchars($reaction['emoji']) . "'>" . htmlspecialchars($reaction['emoji']) . " " . $reaction['count'] . "</span> ";
    }
    echo "</div>";

    // Exibir botões de editar e excluir se o usuário for o autor da postagem
    if ($row['user_id'] == $_SESSION['user_id']) {
        echo "<div class='mt-3'>";
        echo "<a href='edit_post.php?post_id=" . $row['id'] . "' class='btn btn-warning btn-sm'>Editar</a> ";
        echo "<form action='delete_post.php' method='POST' style='display:inline;'>";
        echo "<input type='hidden' name='post_id' value='" . $row['id'] . "'>";
        echo "<button type='submit' class='btn btn-danger btn-sm'>Excluir</button>";
        echo "</form>";
        echo "</div>";
    }

    echo "</div>"; // Fecha media-body
    echo "</div>"; // Fecha media
    echo "</div>"; // Fecha card-body
    echo "</div>"; // Fecha card
}
include 'views/footer.php';
?>

<script>
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.emoji-btn').forEach(button => {
        button.addEventListener('click', function() {
            const postId = this.getAttribute('data-post-id');
            const emoji = this.getAttribute('data-emoji');
            
            // Adicionar a classe de animação
            this.classList.add('animate');
            
            fetch('react_to_post.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ post_id: postId, emoji: emoji })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Remover a classe de animação após 300ms (duração da animação)
                    setTimeout(() => {
                        this.classList.remove('animate');
                        if (data.action === 'added') {
                            this.classList.add('reacted'); // Adiciona um estado visual de reação
                        } else if (data.action === 'removed') {
                            this.classList.remove('reacted'); // Remove o estado de reação
                        }
                    }, 300);
                } else {
                    alert('Erro ao reagir à postagem.');
                }
            });
        });
    });
});

</script>

