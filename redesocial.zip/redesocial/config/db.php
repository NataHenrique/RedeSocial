<?php
$host = 'localhost';
$port = ''; // Porta do banco de dados
$db = 'redesocial';
$user = 'root';
$pass = '';

// Conexão com o banco de dados
try {
    $pdo = new PDO("mysql:host=$host;port=$port;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo 'Erro: ' . $e->getMessage();
    die();
}
session_start(); // Iniciar a sessão
?>
