<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&family=Open+Sans:wght@400;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="path/to/your/styles.css">

<?php
include 'config/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_SESSION['user_id'])) {
    $data = json_decode(file_get_contents('php://input'), true);
    $post_id = $data['post_id'];
    $new_emoji = $data['emoji'];
    $user_id = $_SESSION['user_id'];

    // Verificar se o usuário já reagiu a esta postagem com qualquer emoji
    $stmt = $pdo->prepare('SELECT * FROM reactions WHERE user_id = :user_id AND post_id = :post_id');
    $stmt->execute(['user_id' => $user_id, 'post_id' => $post_id]);
    $existing_reaction = $stmt->fetch();

    if ($existing_reaction) {
        // Se a reação atual é a mesma que o novo emoji, remover a reação
        if ($existing_reaction['emoji'] === $new_emoji) {
            $stmt = $pdo->prepare('DELETE FROM reactions WHERE user_id = :user_id AND post_id = :post_id');
            $stmt->execute(['user_id' => $user_id, 'post_id' => $post_id]);
            echo json_encode(['success' => true, 'action' => 'removed']);
        } else {
            // Caso contrário, atualizar a reação para o novo emoji
            $stmt = $pdo->prepare('UPDATE reactions SET emoji = :emoji WHERE user_id = :user_id AND post_id = :post_id');
            $stmt->execute(['emoji' => $new_emoji, 'user_id' => $user_id, 'post_id' => $post_id]);
            echo json_encode(['success' => true, 'action' => 'updated']);
        }
    } else {
        // Se não houver reação anterior, adicionar uma nova
        $stmt = $pdo->prepare('INSERT INTO reactions (user_id, post_id, emoji) VALUES (:user_id, :post_id, :emoji)');
        $stmt->execute(['user_id' => $user_id, 'post_id' => $post_id, 'emoji' => $new_emoji]);
        echo json_encode(['success' => true, 'action' => 'added']);
    }
} else {
    echo json_encode(['success' => false]);
}
?>
