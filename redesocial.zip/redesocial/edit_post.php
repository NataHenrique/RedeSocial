<?php
include 'config/db.php';

// Verifique se o usuário está logado e se o ID do post foi fornecido
if (!isset($_SESSION['user_id']) || !isset($_GET['post_id'])) {
    header('Location: login.php');
    exit();
}

$post_id = $_GET['post_id'];
$stmt = $pdo->prepare('SELECT * FROM posts WHERE id = :id');
$stmt->execute(['id' => $post_id]);
$post = $stmt->fetch();

if (!$post || $post['user_id'] != $_SESSION['user_id']) {
    echo 'Ação não permitida.';
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $content = $_POST['content'];
    $image_path = $post['image_path']; // Manter a imagem atual por padrão
    $youtube_link = $_POST['youtube_link']; // Novo link do YouTube

    // Verificar se uma nova imagem foi carregada
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($_FILES["image"]["name"]);
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        // Verificar se o arquivo é uma imagem
        $check = getimagesize($_FILES["image"]["tmp_name"]);
        if ($check !== false) {
            move_uploaded_file($_FILES["image"]["tmp_name"], $target_file);
            $image_path = $target_file;
        } else {
            echo 'Arquivo não é uma imagem.';
        }
    }

    // Atualizar a postagem no banco de dados
    $stmt = $pdo->prepare('UPDATE posts SET content = :content, image_path = :image_path, youtube_link = :youtube_link WHERE id = :id');
    $stmt->execute([
        'content' => $content,
        'image_path' => $image_path,
        'youtube_link' => $youtube_link,
        'id' => $post_id
    ]);

    header('Location: feed.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Postagem</title>
    <link href="styles.css" rel="stylesheet">
</head>
<body>
<?php include 'views/header.php'; ?>
<div class="container">
    <h2>Editar Postagem</h2>
    <form action="edit_post.php?post_id=<?php echo $post_id; ?>" method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <label for="content">Conteúdo</label>
            <textarea class="form-control" id="content" name="content" rows="3" required><?php echo htmlspecialchars($post['content']); ?></textarea>
        </div>
        <div class="form-group">
            <label for="image">Imagem</label>
            <?php if ($post['image_path']) : ?>
                <div>
                    <img src="<?php echo htmlspecialchars($post['image_path']); ?>" class="img-fluid mb-3" alt="Post Image">
                </div>
            <?php endif; ?>
            <input type="file" class="form-control-file" id="image" name="image">
        </div>
        <div class="form-group">
            <label for="youtube_link">Link do YouTube</label>
            <input type="url" class="form-control" id="youtube_link" name="youtube_link" value="<?php echo htmlspecialchars($post['youtube_link']); ?>">
        </div>
        <button type="submit" class="btn btn-primary">Salvar</button>
        <a href="feed.php" class="btn btn-secondary">Cancelar</a>
    </form>
</div>
<?php include 'views/footer.php'; ?>
</body>
</html>
