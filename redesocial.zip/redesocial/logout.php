<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&family=Open+Sans:wght@400;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="styles.css">

<?php
session_start();
session_destroy();
header('Location: index.php');
exit();
?>
<style>
/* Definir cores principais */
:root {
    --primary-color: #4a90e2; /* Azul vibrante */
    --secondary-color: #7f8c8d; /* Cinza suave */
    --background-color: #f5f7fa; /* Fundo claro */
    --text-color: #333; /* Texto escuro */
    --link-color: #2980b9; /* Cor dos links */
    --button-primary-bg: #4a90e2; /* Fundo dos botões primários */
    --button-primary-hover-bg: #3a70c2; /* Fundo dos botões primários ao passar o mouse */
    --button-secondary-bg: #7f8c8d; /* Fundo dos botões secundários */
    --button-secondary-hover-bg: #5a6b6e; /* Fundo dos botões secundários ao passar o mouse */
}

/* Tipografia global */
body {
    font-family: 'Montserrat', sans-serif;
    font-size: 16px;
    color: var(--text-color);
    background-color: var(--background-color);
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    line-height: 1.5;
}

/* Cabeçalhos */
h1, h2, h3, h4, h5, h6 {
    font-family: 'Montserrat', sans-serif;
    font-weight: 700;
    color: var(--primary-color);
    margin-bottom: 20px;
}

/* Links */
a {
    color: var(--link-color);
    text-decoration: none;
    transition: color 0.3s;
}

a:hover {
    color: var(--primary-color);
    text-decoration: underline;
}

/* Navbar */
.navbar {
    background-color: var(--primary-color);
    padding: 15px 20px;
    color: white;
    display: flex; /* Usar flexbox para alinhar horizontalmente */
    justify-content: space-between; /* Espaçar os itens adequadamente */
    align-items: center; /* Centralizar verticalmente */
}

.navbar .navbar-brand {
    font-size: 24px;
    color: white;
}

.navbar ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    display: flex; /* Flexbox para manter os itens horizontalmente */
}

.navbar ul li {
    margin: 0 15px; /* Espaçamento entre os itens */
}

.navbar ul li a {
    color: white;
    font-size: 18px;
    text-decoration: none;
    transition: color 0.3s ease;
}

.navbar ul li a:hover {
    color: var(--button-primary-hover-bg);
}

/* Botões */
.btn {
    background-color: var(--button-primary-bg);
    border: none;
    color: white;
    padding: 10px 20px;
    font-size: 16px;
    border-radius: 30px;
    transition: background-color 0.3s ease, transform 0.3s ease;
    cursor: pointer;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
}

.btn:hover {
    background-color: var(--button-primary-hover-bg);
    transform: translateY(-3px);
}

.btn-secondary {
    background-color: var(--button-secondary-bg);
    padding: 10px 20px;
    border-radius: 30px;
}

.btn-secondary:hover {
    background-color: var(--button-secondary-hover-bg);
}

/* Centralização de Conteúdo Principal */
.container {
    max-width: 1200px;
    margin: 0 auto; /* Centraliza horizontalmente */
    padding: 20px;
}

/* Centralização específica de elementos como Jumbotron */
.jumbotron {
    background-color: var(--primary-color);
    color: white;
    padding: 60px 30px;
    text-align: center;
    border-radius: 12px;
    margin-bottom: 40px;
}

/* Cartões */
.card {
    background-color: white;
    border-radius: 12px;
    padding: 20px;
    margin: 20px auto; /* Centralizar horizontalmente */
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
    transition: box-shadow 0.3s ease;
}

.card:hover {
    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
}

.card-body {
    padding: 20px;
}

/* Imagens do Feed */
.card img {
    max-width: 100%; /* Imagem ocupa a largura total do container */
    height: auto; /* Altura ajustada automaticamente */
    margin-bottom: 15px;
    border-radius: 8px;
}

/* Ajuste do tamanho das imagens no feed */
.card img {
    max-width: 100%;
    height: auto;
    margin-bottom: 15px;
    border-radius: 8px;
    max-height: 400px; /* Limite de altura para manter proporção */
    object-fit: cover; /* Assegurar que a imagem preencha o espaço */
}

/* Formulários */
.form-control {
    border-radius: 12px;
    padding: 10px 15px;
    border: 1px solid #ccc;
    font-size: 16px;
    transition: border-color 0.3s, box-shadow 0.3s;
}

.form-control:focus {
    border-color: var(--primary-color);
    box-shadow: 0 0 8px rgba(0, 144, 255, 0.3);
    outline: none;
}

.form-group {
    margin-bottom: 20px;
}

/* Reações e Emojis */
.emoji-reactions {
    display: flex;
    gap: 15px;
    margin-top: 15px;
}

.emoji-btn {
    font-size: 24px;
    padding: 5px;
    border-radius: 50%;
    background-color: var(--secondary-color);
    color: white;
    cursor: pointer;
    transition: transform 0.2s, background-color 0.2s;
}

.emoji-btn:hover {
    background-color: var(--primary-color);
    transform: scale(1.2);
}

/* Reações Summary */
.reactions-summary {
    margin-top: 10px;
    font-size: 14px;
    color: #666;
}

/* Footer */
.footer {
    background-color: var(--secondary-color);
    color: white;
    padding: 20px;
    text-align: center;
    font-size: 0.9rem;
    margin-top: 40px;
}

/* Responsividade */
@media (max-width: 768px) {
    .navbar a {
        font-size: 16px;
    }

    .jumbotron h1 {
        font-size: 2.2rem;
    }

    .jumbotron p {
        font-size: 1rem;
    }
}

    /* Container principal da página de login */
    .login-container {
    max-width: 400px;
    margin: 100px auto; /* Centraliza o container verticalmente e horizontalmente */
    padding: 40px;
    background-color: white; /* Cor de fundo do quadrado */
    border-radius: 15px; /* Cantos arredondados */
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1); /* Sombra suave */
    text-align: center; /* Centraliza o conteúdo dentro do container */
}

/* Estilo dos campos de formulário */
.login-container .form-group {
    margin-bottom: 20px;
}

.login-container label {
    font-weight: 600;
    color: var(--primary-color); /* Cor coerente com a paleta de cores */
}

.login-container .form-control {
    width: 100%;
    padding: 10px;
    border-radius: 10px;
    border: 1px solid #ced4da;
    font-size: 16px;
    transition: border-color 0.3s ease, box-shadow 0.3s ease;
}

.login-container .form-control:focus {
    border-color: var(--primary-color); /* Cor de foco coerente */
    box-shadow: 0px 0px 8px rgba(0, 123, 255, 0.25);
    outline: none;
}

/* Botão de Login */
.login-container .btn-primary {
    background-color: var(--primary-color);
    border: none;
    padding: 12px 20px;
    font-size: 16px;
    border-radius: 10px;
    width: 100%;
    transition: background-color 0.3s ease, transform 0.2s ease;
}

.login-container .btn-primary:hover {
    background-color: var(--button-primary-hover-bg);
    transform: translateY(-3px); /* Efeito de salto leve no hover */
}

/* Ajustes para links */
.login-container a {
    color: var(--link-color);
    text-decoration: none;
    font-size: 14px;
    display: block;
    margin-top: 15px;
    transition: color 0.3s ease;
}

.login-container a:hover {
    color: var(--primary-color);
    text-decoration: underline;
}

/* Responsividade */
@media (max-width: 768px) {
    .login-container {
        margin: 50px auto;
        padding: 30px;
    }
}


</style>