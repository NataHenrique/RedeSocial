</div> <!-- Fecha container -->

<!-- jQuery e Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<!-- Script para Reações -->
<script>
$(document).ready(function(){
    $('.reaction-button').on('click', function(){
        const postId = $(this).data('post-id');
        const emoji = $(this).data('emoji');
        
        $.ajax({
            url: 'react_to_post.php',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ post_id: postId, emoji: emoji }),
            success: function(response) {
                const data = JSON.parse(response);
                if (data.success) {
                    if (data.action === 'added') {
                        $(`#post-${postId} .reaction-display`).text(`Você reagiu com ${emoji}`);
                    } else if (data.action === 'updated') {
                        $(`#post-${postId} .reaction-display`).text(`Você alterou sua reação para ${emoji}`);
                    } else if (data.action === 'removed') {
                        $(`#post-${postId} .reaction-display`).text('Você removeu sua reação');
                    }
                }
            },
            error: function() {
                alert('Erro ao processar a reação. Por favor, tente novamente.');
            }
        });
    });
});
</script>

</body>
</html>
