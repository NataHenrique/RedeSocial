<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&family=Open+Sans:wght@400;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="styles.css">

<?php
include 'config/db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Atualizar foto de perfil
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['new_profile_pic'])) {
    $user_id = $_SESSION['user_id'];
    $upload_dir = 'profile_pics/';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }
    $profile_pic = $upload_dir . basename($_FILES['new_profile_pic']['name']);
    if (move_uploaded_file($_FILES['new_profile_pic']['tmp_name'], $profile_pic)) {
        $stmt = $pdo->prepare('UPDATE users SET profile_pic = :profile_pic WHERE id = :id');
        $stmt->execute(['profile_pic' => $profile_pic, 'id' => $user_id]);
        $_SESSION['profile_pic'] = $profile_pic; // Atualiza a foto de perfil na sessão
        header('Location: profile.php');
        exit();
    } else {
        $error = 'Erro ao fazer upload da foto de perfil.';
    }
}

$stmt = $pdo->prepare('SELECT username, profile_pic FROM users WHERE id = :id');
$stmt->execute(['id' => $_SESSION['user_id']]);
$user = $stmt->fetch();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil - Mini Rede Social</title>
    <!-- Materialize CSS -->

    <link href="styles.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="#">Mini Rede Social</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
            <li class="nav-item"><a class="nav-link" href="profile.php">Perfil</a></li>
            <li class="nav-item"><a class="nav-link" href="feed.php">Feed</a></li>
            <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
        </ul>
    </div>
</nav>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-8 offset-md-2">
            <div class="card">
                <div class="card-body text-center">
                    <?php if ($user['profile_pic']): ?>
                        <img src="<?php echo htmlspecialchars($user['profile_pic']); ?>" alt="Foto de perfil" class="img-thumbnail mb-3" style="width: 150px; height: 150px;">
                    <?php else: ?>
                        <img src="default-profile.png" alt="Foto de perfil padrão" class="img-thumbnail mb-3" style="width: 150px; height: 150px;">
                    <?php endif; ?>
                    <h2 class="card-title">Perfil</h2>
                    <p class="card-text">Bem-vindo, <?php echo htmlspecialchars($user['username']); ?>!</p>
                    <?php if (isset($error)): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>
                    <form action="profile.php" method="POST" enctype="multipart/form-data" class="mb-3">
                        <div class="form-group">
                            <label for="new_profile_pic">Atualizar foto de perfil:</label>
                            <input type="file" id="new_profile_pic" name="new_profile_pic" class="form-control">
                        </div>
                        <button type="submit" class="btn btn-primary btn-block">Atualizar Foto</button>
                    </form>
                    <form action="post_status.php" method="POST" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="status">Postar uma atualização de status:</label>
                            <textarea id="status" name="status" class="form-control" rows="3" required></textarea>
                        </div>
                        <div class="form-group">
                            <label for="image">Upload de imagem:</label>
                            <input type="file" id="image" name="image" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="youtube_link">Link do YouTube:</label>
                            <input type="url" id="youtube_link" name="youtube_link" class="form-control">
                        </div>
                        <button type="submit" class="btn btn-primary btn-block">Postar</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

<style>
/* Definir cores principais */
:root {
    --primary-color: #4a90e2; /* Azul vibrante */
    --secondary-color: #7f8c8d; /* Cinza suave */
    --background-color: #f5f7fa; /* Fundo claro */
    --text-color: #333; /* Texto escuro */
    --link-color: #2980b9; /* Cor dos links */
    --button-primary-bg: #4a90e2; /* Fundo dos botões primários */
    --button-primary-hover-bg: #3a70c2; /* Fundo dos botões primários ao passar o mouse */
    --button-secondary-bg: #7f8c8d; /* Fundo dos botões secundários */
    --button-secondary-hover-bg: #5a6b6e; /* Fundo dos botões secundários ao passar o mouse */
}

/* Tipografia global */
body {
    font-family: 'Montserrat', sans-serif;
    font-size: 16px;
    color: var(--text-color);
    background-color: var(--background-color);
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    line-height: 1.5;
}

/* Cabeçalhos */
h1, h2, h3, h4, h5, h6 {
    font-family: 'Montserrat', sans-serif;
    font-weight: 700;
    color: var(--primary-color);
    margin-bottom: 20px;
}

/* Links */
a {
    color: var(--link-color);
    text-decoration: none;
    transition: color 0.3s;
}

a:hover {
    color: var(--primary-color);
    text-decoration: underline;
}

/* Navbar */
.navbar {
    background-color: var(--primary-color);
    padding: 15px 20px;
    color: white;
    display: flex; /* Usar flexbox para alinhar horizontalmente */
    justify-content: space-between; /* Espaçar os itens adequadamente */
    align-items: center; /* Centralizar verticalmente */
}

.navbar .navbar-brand {
    font-size: 24px;
    color: white;
}

.navbar ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    display: flex; /* Flexbox para manter os itens horizontalmente */
}

.navbar ul li {
    margin: 0 15px; /* Espaçamento entre os itens */
}

.navbar ul li a {
    color: white;
    font-size: 18px;
    text-decoration: none;
    transition: color 0.3s ease;
}

.navbar ul li a:hover {
    color: var(--button-primary-hover-bg);
}

/* Botões */
.btn {
    background-color: var(--button-primary-bg);
    border: none;
    color: white;
    padding: 10px 20px;
    font-size: 16px;
    border-radius: 30px;
    transition: background-color 0.3s ease, transform 0.3s ease;
    cursor: pointer;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
}

.btn:hover {
    background-color: var(--button-primary-hover-bg);
    transform: translateY(-3px);
}

.btn-secondary {
    background-color: var(--button-secondary-bg);
    padding: 10px 20px;
    border-radius: 30px;
}

.btn-secondary:hover {
    background-color: var(--button-secondary-hover-bg);
}

/* Centralização de Conteúdo Principal */
.container {
    max-width: 1200px;
    margin: 0 auto; /* Centraliza horizontalmente */
    padding: 20px;
}

/* Centralização específica de elementos como Jumbotron */
.jumbotron {
    background-color: var(--primary-color);
    color: white;
    padding: 60px 30px;
    text-align: center;
    border-radius: 12px;
    margin-bottom: 40px;
}

/* Cartões */
.card {
    background-color: white;
    border-radius: 12px;
    padding: 20px;
    margin: 20px auto; /* Centralizar horizontalmente */
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
    transition: box-shadow 0.3s ease;
}

.card:hover {
    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
}

.card-body {
    padding: 20px;
}

/* Imagens do Feed */
.card img {
    max-width: 100%; /* Imagem ocupa a largura total do container */
    height: auto; /* Altura ajustada automaticamente */
    margin-bottom: 15px;
    border-radius: 8px;
}

/* Ajuste do tamanho das imagens no feed */
.card img {
    max-width: 100%;
    height: auto;
    margin-bottom: 15px;
    border-radius: 8px;
    max-height: 400px; /* Limite de altura para manter proporção */
    object-fit: cover; /* Assegurar que a imagem preencha o espaço */
}

/* Formulários */
.form-control {
    border-radius: 12px;
    padding: 10px 15px;
    border: 1px solid #ccc;
    font-size: 16px;
    transition: border-color 0.3s, box-shadow 0.3s;
}

.form-control:focus {
    border-color: var(--primary-color);
    box-shadow: 0 0 8px rgba(0, 144, 255, 0.3);
    outline: none;
}

.form-group {
    margin-bottom: 20px;
}

/* Reações e Emojis */
.emoji-reactions {
    display: flex;
    gap: 15px;
    margin-top: 15px;
}

.emoji-btn {
    font-size: 24px;
    padding: 5px;
    border-radius: 50%;
    background-color: var(--secondary-color);
    color: white;
    cursor: pointer;
    transition: transform 0.2s, background-color 0.2s;
}

.emoji-btn:hover {
    background-color: var(--primary-color);
    transform: scale(1.2);
}

/* Reações Summary */
.reactions-summary {
    margin-top: 10px;
    font-size: 14px;
    color: #666;
}

/* Footer */
.footer {
    background-color: var(--secondary-color);
    color: white;
    padding: 20px;
    text-align: center;
    font-size: 0.9rem;
    margin-top: 40px;
}

/* Responsividade */
@media (max-width: 768px) {
    .navbar a {
        font-size: 16px;
    }

    .jumbotron h1 {
        font-size: 2.2rem;
    }

    .jumbotron p {
        font-size: 1rem;
    }
}


</style>